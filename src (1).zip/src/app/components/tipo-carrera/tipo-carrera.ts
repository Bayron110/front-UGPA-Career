import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-tipo-carrera',
  imports: [CommonModule, FormsModule],
  templateUrl: './tipo-carrera.html',
  styleUrl: './tipo-carrera.css'
})
export class TipoCarrera {
nombreTipo: string = '';
duraciones: number[] = [0]; 

agregarDuracion(): void {
  this.duraciones.push(0);
}


}
