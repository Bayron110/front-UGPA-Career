import { Component } from '@angular/core';

@Component({
  selector: 'app-carrera-i',
  imports: [],
  templateUrl: './carrera-i.html',
  styleUrl: './carrera-i.css'
})
export class CarreraI {

}
